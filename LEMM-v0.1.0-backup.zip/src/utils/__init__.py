"""Utility functions for LEMM"""
