"""
LEMM (Let Everyone Make Music) - AI Music Generator
Main package initialization
"""

__version__ = "0.1.0"
__author__ = "LEMM Team"
