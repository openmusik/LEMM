"""Audio processing modules for LEMM"""
